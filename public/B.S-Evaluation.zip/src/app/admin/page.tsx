'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Shield,
  Plus,
  Trash2,
  LogOut,
  ArrowRight,
  Loader2,
  Users,
  RefreshCw,
  AlertCircle,
  KeyRound,
  UserCog,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogAction,
  AlertDialogCancel,
} from '@/components/ui/alert-dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useAuthStore, waitForAuthHydration } from '@/stores';
import { useTranslation } from '@/lib/i18n';

// ======== Types ========
interface User {
  id: string;
  username: string;
  fullName: string;
  role: 'admin' | 'user';
  created_at: string;
}

// ======== Admin Page Component ========
export default function AdminPage() {
  const router = useRouter();
  const { user, clearAuth } = useAuthStore();
  const { t, dir, isRTL } = useTranslation('ar');

  // ======== State ========
  const [mounted, setMounted] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(true);
  const [error, setError] = useState('');

  // Add user dialog
  const [showAddUserDialog, setShowAddUserDialog] = useState(false);
  const [newUserForm, setNewUserForm] = useState({
    username: '',
    password: '',
    fullName: '',
  });
  const [isAddingUser, setIsAddingUser] = useState(false);

  // Delete confirmations
  const [deleteUserTarget, setDeleteUserTarget] = useState<User | null>(null);
  const [isDeletingUser, setIsDeletingUser] = useState(false);

  // Reset password dialog
  const [resetPasswordTarget, setResetPasswordTarget] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [isResettingPassword, setIsResettingPassword] = useState(false);

  // Role change
  const [changingRoleUserId, setChangingRoleUserId] = useState<string | null>(null);

  // ======== Wait for zustand hydration + redirect non-admin ========
  useEffect(() => {
    let cancelled = false;
    waitForAuthHydration().then(() => {
      if (!cancelled) setMounted(true);
    });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!mounted) return;
    if (user && user.role !== 'admin') {
      router.replace('/');
    }
  }, [mounted, user, router]);

  // ======== Fetch users ========
  const fetchUsers = useCallback(async () => {
    setIsLoadingUsers(true);
    setError('');
    try {
      const res = await fetch('/api/admin/users');
      if (!res.ok) {
        const data = await res.json();
        setError(data.error || 'فشل في تحميل المستخدمين');
        return;
      }
      const data = await res.json();
      setUsers(data);
    } catch {
      setError('تعذر الاتصال بالخادم');
    } finally {
      setIsLoadingUsers(false);
    }
  }, []);

  useEffect(() => {
    if (user?.role === 'admin') {
      fetchUsers();
    }
  }, [user, fetchUsers]);

  // ======== Add user ========
  const handleAddUser = async () => {
    if (!newUserForm.username.trim() || !newUserForm.password.trim() || !newUserForm.fullName.trim()) {
      return;
    }
    setIsAddingUser(true);
    setError('');
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: newUserForm.username.trim(),
          password: newUserForm.password,
          fullName: newUserForm.fullName.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'فشل في إضافة المستخدم');
        return;
      }
      setShowAddUserDialog(false);
      setNewUserForm({ username: '', password: '', fullName: '' });
      await fetchUsers();
    } catch {
      setError('تعذر الاتصال بالخادم');
    } finally {
      setIsAddingUser(false);
    }
  };

  // ======== Delete user ========
  const handleDeleteUser = async () => {
    if (!deleteUserTarget) return;
    setIsDeletingUser(true);
    setError('');
    try {
      const res = await fetch(`/api/admin/users/${deleteUserTarget.id}`, {
        method: 'DELETE',
      });
      if (!res.ok) {
        const data = await res.json();
        setError(data.error || 'فشل في حذف المستخدم');
        return;
      }
      setDeleteUserTarget(null);
      await fetchUsers();
    } catch {
      setError('تعذر الاتصال بالخادم');
    } finally {
      setIsDeletingUser(false);
    }
  };

  // ======== Change user role ========
  const handleToggleRole = async (targetUser: User) => {
    const newRole = targetUser.role === 'admin' ? 'user' : 'admin';
    setChangingRoleUserId(targetUser.id);
    setError('');
    try {
      const res = await fetch(`/api/admin/users/${targetUser.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'فشل في تغيير الدور');
        return;
      }
      await fetchUsers();
    } catch {
      setError('تعذر الاتصال بالخادم');
    } finally {
      setChangingRoleUserId(null);
    }
  };

  // ======== Reset user password ========
  const handleResetPassword = async () => {
    if (!resetPasswordTarget || !newPassword.trim()) return;
    setIsResettingPassword(true);
    setError('');
    try {
      const res = await fetch(`/api/admin/users/${resetPasswordTarget.id}/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: newPassword.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'فشل في إعادة تعيين كلمة المرور');
        return;
      }
      setResetPasswordTarget(null);
      setNewPassword('');
    } catch {
      setError('تعذر الاتصال بالخادم');
    } finally {
      setIsResettingPassword(false);
    }
  };

  // ======== Logout ========
  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    clearAuth();
    window.location.href = '/login';
  };

  // ======== Format date ========
  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleDateString('ar-SY', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  // ======== Guard: show nothing while hydrating or checking role ========
  if (!mounted || !user) {
    return (
      <div dir={dir} className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (user.role !== 'admin') {
    return null;
  }

  // ======== Render ========
  return (
    <div dir={dir} className="min-h-screen flex flex-col bg-gray-50/80">
      {/* ======== Header / Navbar ======== */}
      <header className="sticky top-0 z-30 bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-emerald-600 shadow-md">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-bold text-gray-800">
                إدارة المستخدمين
              </h1>
              <p className="text-xs text-gray-500 hidden sm:block">
                لوحة تحكم المشرفين — B.S Evaluation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" asChild className="gap-1.5 text-sm">
              <Link href="/">
                <ArrowRight className="w-4 h-4" />
                <span className="hidden sm:inline">الرئيسية</span>
              </Link>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="gap-1.5 text-sm text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">خروج</span>
            </Button>
          </div>
        </div>
      </header>

      {/* ======== Main Content ======== */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 space-y-6">
        {/* Error Banner */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-800 rounded-xl px-4 py-3 flex items-center gap-3 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0 text-red-500" />
            <span className="flex-1">{error}</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setError('')}
              className="text-red-600 hover:text-red-800 hover:bg-red-100 h-auto px-2"
            >
              ✕
            </Button>
          </div>
        )}

        {/* Stats Cards Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
          <Card className="py-4">
            <CardContent className="px-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-emerald-100">
                  <Users className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">{users.length}</p>
                  <p className="text-xs text-gray-500">المستخدمون</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="py-4">
            <CardContent className="px-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-blue-100">
                  <Shield className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">
                    {users.filter((u) => u.role === 'admin').length}
                  </p>
                  <p className="text-xs text-gray-500">المشرفون</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="py-4 col-span-2 sm:col-span-1">
            <CardContent className="px-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-amber-100">
                  <Users className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">
                    {users.filter((u) => u.role === 'user').length}
                  </p>
                  <p className="text-xs text-gray-500">المستخدمون العاديون</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Users Table Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <CardTitle className="text-lg font-bold text-gray-800 flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-600" />
              قائمة المستخدمين
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={fetchUsers}
                disabled={isLoadingUsers}
                className="gap-1.5"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingUsers ? 'animate-spin' : ''}`} />
                <span className="hidden sm:inline">تحديث</span>
              </Button>
              <Button
                size="sm"
                onClick={() => setShowAddUserDialog(true)}
                className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة مستخدم</span>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="px-0 pb-0">
            {/* Loading State */}
            {isLoadingUsers && users.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 text-gray-400">
                <Loader2 className="w-8 h-8 animate-spin mb-3" />
                <p className="text-sm">جاري تحميل المستخدمين...</p>
              </div>
            )}

            {/* Empty State */}
            {!isLoadingUsers && users.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 text-gray-400">
                <Users className="w-12 h-12 mb-3 opacity-50" />
                <p className="text-sm font-medium">لا يوجد مستخدمون حالياً</p>
                <p className="text-xs mt-1">اضغط على &quot;إضافة مستخدم&quot; لإنشاء حساب جديد</p>
              </div>
            )}

            {/* Users Table */}
            {users.length > 0 && (
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50/80 hover:bg-gray-50/80">
                    <TableHead className="text-right font-semibold text-gray-600 px-4 py-3">
                      اسم المستخدم
                    </TableHead>
                    <TableHead className="text-right font-semibold text-gray-600 px-4 py-3 hidden sm:table-cell">
                      الاسم الكامل
                    </TableHead>
                    <TableHead className="text-center font-semibold text-gray-600 px-4 py-3">
                      الدور
                    </TableHead>
                    <TableHead className="text-right font-semibold text-gray-600 px-4 py-3 hidden md:table-cell">
                      تاريخ التسجيل
                    </TableHead>
                    <TableHead className="text-center font-semibold text-gray-600 px-4 py-3">
                      الإجراءات
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((u) => (
                    <TableRow key={u.id} className="group">
                      <TableCell className="px-4 py-3">
                        <p className="font-medium text-gray-800">{u.username}</p>
                        <p className="text-xs text-gray-500 sm:hidden">{u.fullName}</p>
                      </TableCell>
                      <TableCell className="px-4 py-3 hidden sm:table-cell text-gray-700">
                        {u.fullName}
                      </TableCell>
                      <TableCell className="px-4 py-3 text-center">
                        <Badge
                          variant={u.role === 'admin' ? 'default' : 'secondary'}
                          className={
                            u.role === 'admin'
                              ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                          }
                        >
                          {u.role === 'admin' ? 'مشرف' : 'مستخدم'}
                        </Badge>
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-sm hidden md:table-cell">
                        {formatDate(u.created_at)}
                      </TableCell>
                      <TableCell className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          {/* Role Toggle */}
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleToggleRole(u)}
                            disabled={u.id === user.id || changingRoleUserId === u.id}
                            title={u.id === user.id ? 'لا يمكنك تغيير دورك' : u.role === 'admin' ? 'تحويل إلى مستخدم عادي' : 'ترقية إلى مشرف'}
                            className="h-8 w-8 text-blue-500 hover:text-blue-700 hover:bg-blue-50 disabled:opacity-30"
                          >
                            {changingRoleUserId === u.id
                              ? <Loader2 className="w-4 h-4 animate-spin" />
                              : <UserCog className="w-4 h-4" />
                            }
                          </Button>

                          {/* Reset Password */}
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { setResetPasswordTarget(u); setNewPassword(''); }}
                            disabled={u.id === user.id}
                            title={u.id === user.id ? 'لا يمكنك تغيير كلمة مرورك من هنا' : 'إعادة تعيين كلمة المرور'}
                            className="h-8 w-8 text-amber-500 hover:text-amber-700 hover:bg-amber-50 disabled:opacity-30"
                          >
                            <KeyRound className="w-4 h-4" />
                          </Button>

                          {/* Delete User */}
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setDeleteUserTarget(u)}
                            disabled={u.role === 'admin'}
                            title={u.role === 'admin' ? 'لا يمكن حذف مشرف' : 'حذف المستخدم'}
                            className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50 disabled:opacity-30"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </main>

      {/* ======== Add User Dialog ======== */}
      <Dialog open={showAddUserDialog} onOpenChange={setShowAddUserDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-gray-800">
              <Plus className="w-5 h-5 text-emerald-600" />
              إضافة مستخدم جديد
            </DialogTitle>
            <DialogDescription>أدخل بيانات المستخدم الجديد لإنشاء حساب</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="new-username" className="font-medium">
                اسم المستخدم
              </Label>
              <Input
                id="new-username"
                placeholder="مثال: engineer1"
                value={newUserForm.username}
                onChange={(e) =>
                  setNewUserForm((prev) => ({ ...prev, username: e.target.value }))
                }
                disabled={isAddingUser}
                className="text-right"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password" className="font-medium">
                كلمة المرور
              </Label>
              <Input
                id="new-password"
                type="password"
                placeholder="8 أحرف على الأقل"
                value={newUserForm.password}
                onChange={(e) =>
                  setNewUserForm((prev) => ({ ...prev, password: e.target.value }))
                }
                disabled={isAddingUser}
                className="text-right"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-fullname" className="font-medium">
                الاسم الكامل
              </Label>
              <Input
                id="new-fullname"
                placeholder="مثال: أحمد محمد"
                value={newUserForm.fullName}
                onChange={(e) =>
                  setNewUserForm((prev) => ({ ...prev, fullName: e.target.value }))
                }
                disabled={isAddingUser}
                className="text-right"
              />
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => {
                setShowAddUserDialog(false);
                setNewUserForm({ username: '', password: '', fullName: '' });
              }}
              disabled={isAddingUser}
            >
              إلغاء
            </Button>
            <Button
              onClick={handleAddUser}
              disabled={
                isAddingUser ||
                !newUserForm.username.trim() ||
                !newUserForm.password.trim() ||
                !newUserForm.fullName.trim()
              }
              className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              {isAddingUser ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  جاري الإضافة...
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  إضافة المستخدم
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ======== Delete User Confirmation ======== */}
      <AlertDialog open={!!deleteUserTarget} onOpenChange={(open) => !open && setDeleteUserTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-700">
              <AlertCircle className="w-5 h-5" />
              تأكيد حذف المستخدم
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-600 leading-relaxed">
              هل أنت متأكد من حذف المستخدم{' '}
              <span className="font-bold text-gray-800">{deleteUserTarget?.fullName}</span>
              {' '}({deleteUserTarget?.username})؟
              <br />
              سيتم حذف جميع بياناته نهائياً ولا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2 sm:gap-0">
            <AlertDialogCancel disabled={isDeletingUser}>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteUser}
              disabled={isDeletingUser}
              className="bg-red-600 hover:bg-red-700 text-white gap-1.5"
            >
              {isDeletingUser ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  جاري الحذف...
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4" />
                  حذف المستخدم
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ======== Reset Password Dialog ======== */}
      <Dialog open={!!resetPasswordTarget} onOpenChange={(open) => {
        if (!open) { setResetPasswordTarget(null); setNewPassword(''); }
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-gray-800">
              <KeyRound className="w-5 h-5 text-amber-600" />
              إعادة تعيين كلمة المرور
            </DialogTitle>
            <DialogDescription>
              تعيين كلمة مرور جديدة للمستخدم{' '}
              <span className="font-bold text-gray-800">{resetPasswordTarget?.fullName}</span>
              {' '}({resetPasswordTarget?.username})
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="reset-password" className="font-medium">
                كلمة المرور الجديدة
              </Label>
              <Input
                id="reset-password"
                type="password"
                placeholder="8 أحرف على الأقل"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                disabled={isResettingPassword}
                className="text-right"
                onKeyDown={(e) => e.key === 'Enter' && handleResetPassword()}
              />
              <p className="text-xs text-gray-500">
                يجب أن تكون 8 أحرف على الأقل و 128 حرف كحد أقصى
              </p>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => { setResetPasswordTarget(null); setNewPassword(''); }}
              disabled={isResettingPassword}
            >
              إلغاء
            </Button>
            <Button
              onClick={handleResetPassword}
              disabled={isResettingPassword || newPassword.trim().length < 8}
              className="gap-1.5 bg-amber-600 hover:bg-amber-700 text-white"
            >
              {isResettingPassword ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  جاري التعيين...
                </>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  تعيين كلمة المرور
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
